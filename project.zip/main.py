import numpy as np
import pandas as pd 
from scipy import stats
import yfinance as yf
from datetime import datetime, timedelta


"""
df_asset = yf.download('AAPL', start='2020-01-01', end='2025-01-01')

df_rf = yf.download('^IRX', start='2020-01-01', end='2025-01-01')

def_market = yf.download('^GSPC', start='2020-01-01', end='2025-01-01')

df_asset.to_csv("AAPL_data.csv")
df_rf.to_csv("AAPL_rf_data.csv")
def_market.to_csv("AAPL_market_data.csv")
"""


"""def load_csv(path):
    df = pd.read_csv(path, index_col=0)
    # drop junk header rows from yfinance (e.g. "Ticker", "Date") if present
    df = df[pd.to_datetime(df.index, errors="coerce", utc=True).notna()]
    # convert to a proper DatetimeIndex, strip the timezone
    df.index = pd.to_datetime(df.index, utc=True).tz_localize(None)
    df.index.name = "Date"
    # make sure the numbers are numeric (junk rows can turn columns into strings)
    return df.apply(pd.to_numeric, errors="coerce")

df_asset = load_csv("AAPL.csv")
df_rf = load_csv("rf.csv")
df_market = load_csv("market.csv")


def monthly_returns(df):
    df = df.resample('ME').last()
    df['Monthly Return'] = df['Close'].pct_change()
    return df


df_asset = monthly_returns(df_asset)
df_market = monthly_returns(df_market)    
df_rf = monthly_returns(df_rf)

df_asset.to_csv("AAPL.csv")
df_rf.to_csv("rf.csv")
df_market.to_csv("market.csv")

df_asset.drop(columns=['Open', 'High', 'Low', 'Volume', 'Close'], inplace=True)
df_market.drop(columns=['Open', 'High', 'Low', 'Volume', 'Close'], inplace=True)
df_rf.drop(columns=['Open', 'High', 'Low', 'Volume', 'Close'], inplace=True)
df_asset = df_asset.rename(columns={'Monthly Return': 'Ri_AAPL'})
df_rf = df_rf.rename(columns={'Monthly Return': 'RF'})
df_market = df_market.rename(columns={'Monthly Return': 'RM'})

df_merged = pd.merge(df_asset, df_rf, left_index=True, right_index=True, how='inner')
df_merged = pd.merge(df_merged, df_market, left_index=True, right_index=True, how='inner')

print(df_asset.columns)
print(df_rf.columns)
print(df_merged.columns)"""

#df_merged.to_csv("dataset.csv")

df = pd.read_csv("dataset.csv", index_col=0)


def CAPM(x, y):
    n = len(y)
    beta = np.sum((x - np.mean(x)) * (y - np.mean(y))) / np.sum((x - np.mean(x)) ** 2)
    print("Beta:", beta)


x = df['RM']
y = df['Ri_AAPL']

CAPM(x, y)